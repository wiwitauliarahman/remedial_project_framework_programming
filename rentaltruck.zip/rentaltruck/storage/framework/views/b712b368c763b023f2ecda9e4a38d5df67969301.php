<?php $__env->startSection('container'); ?>
<div class="container-fluid">

    <form action="/foto/" method="GET">
		<input type="text" name="cari" placeholder="Cari Kendaraan ..">
		<input type="submit" value="CARI">
	</form>
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
    <br/>

                <a href="/foto/tambah" class="btn btn-primary">Tambah</a>
                <br>
                <br>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title m-b-0">Foto</h5>
                            </div>
                            <table class="table">
                                  <thead class="thead-dark">
                                  <tr>
                                      <th scope="col">Foto ID</th>
                                      <th scope="col">Nama</th>
                                      <th scope="col">Alamat</th>
                                      <th scope="col">Telephon</th>
                                      <th scope="col">Foto</th>
                                      <th scope="col">Opsi</th>
                                    </tr>
                                  </thead>
                                  <tbody>

                                  <?php $__currentLoopData = $data_foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                               <tr>
			                               <td><?php echo e($foto->id); ?></td>
			                               <td><?php echo e($foto->foto_nama); ?></td>
			                              <td><?php echo e($foto->foto_alamat); ?></td>
                                          <td><?php echo e($foto->foto_telpon); ?></td>
                                          <td><img src="<?php echo e(asset('/storage/gambar/'.$foto->foto_foto)); ?>" class="card-img-top" width="30px" height="100px" alt="..."></td>
			                              <td>
                                            
				                            <a href="/foto/<?php echo e($foto->id); ?>/edit" class="btn btn-warning">Edit</a>
				                           <a href="/foto/<?php echo e($foto->id); ?>/delete" class="btn btn-danger"onClick="return confirm('Yakin Mau Di Hapus ?')">Hapus</a>
			                              </td>
		                               </tr>
		                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </tbody>
                            </table>

                                                               <br/>
	                Halaman : <?php echo e($data_foto->currentPage()); ?> <br/>
	            Jumlah Data : <?php echo e($data_foto->total()); ?> <br/>
	       Data Per Halaman : <?php echo e($data_foto->perPage()); ?> <br/>


	           <?php echo e($data_foto->links()); ?>

                        </div>

                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
<?php $__env->stopSection(); ?>


































<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\rentalmobil\resources\views//foto.blade.php ENDPATH**/ ?>