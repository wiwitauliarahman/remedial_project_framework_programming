<?php $__env->startSection('container'); ?>
<div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                   Edit Foto
                </div>
                <div class="card-body">
                    <a href="/foto" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>

                    <form method="post" action="/foto/<?php echo e($foto->id); ?>/update" enctype="multipart/form-data" >

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label>Foto ID</label>
                            <input  type="text" name="id" class="form-control" value="<?php echo e($foto->id); ?>">
                        </div>
                        <div class="form-group">
                            <label>Nama</label>
                            <input  type="text" name="foto_nama" class="form-control" value="<?php echo e($foto->foto_nama); ?>">
                        </div>


                        <div class="form-group">
                            <label>Alamat</label>
                            <input type="text" name="foto_alamat" value="<?php echo e($foto->foto_alamat); ?>"class="form-control" placeholder="Masukan Alamat"></input>
                        </div>

                        <div class="form-group">
                            <label>Telephon</label>
                            <input type="text" name="foto_telpon" value="<?php echo e($foto->foto_telpon); ?>"class="form-control" placeholder="Masukan Telpon"></input>
                        </div>

                        <div class="form-group">
                            <label for="foto_foto"> Foto</label>
                            <?php if($foto->foto_foto != NULL): ?>
                            <div>
                                <input type="hidden" name="oldgambar" value="<?php echo e($foto->foto_foto); ?>">
                                <img src="<?php echo e(asset('storage/gambar/'.$foto->foto_foto)); ?>" class="w-25">
                            </div>
                            <?php endif; ?>
                            <input type="file" name="foto_foto" class="form-control-file form-control-sm" id="foto_foto"/>
                        </div>

                        


                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>

                    </form>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\rentalmobil\resources\views/foto_edit.blade.php ENDPATH**/ ?>