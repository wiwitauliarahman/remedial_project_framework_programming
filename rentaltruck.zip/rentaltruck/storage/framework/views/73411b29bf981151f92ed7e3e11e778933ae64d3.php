<?php $__env->startSection('container'); ?>
<div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    TAMBAH FOTO
                </div>
                <div class="card-body">
                    <a href="/foto" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>

                    <form method="post" action="/foto/create" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>



                        <div class="form-group">
                            <label>Nama</label>
                            <input name="foto_nama" class="form-control" placeholder="Masukan Nama "></input>

                             <?php if($errors->has('nama')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('nama')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Alamat</label>
                            <input name="foto_alamat" class="form-control" placeholder="Masukan Alamat"></input>

                             <?php if($errors->has('foto_alamat')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('foto_alamat')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Telepon</label>
                            <input name="foto_telpon" class="form-control" placeholder="Masukan Telephone"></input>

                             <?php if($errors->has('foto_telpon')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('foto_telpon')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Foto</label>
                            <input type="file" name="foto_foto" class="form-control" placeholder="Masukan Foto"></input>

                             <?php if($errors->has('foto_foto')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('foto_foto')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        

                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>

                    </form>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\rentalmobil\resources\views/foto_tambah.blade.php ENDPATH**/ ?>