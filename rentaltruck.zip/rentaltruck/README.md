LARAVEL 2020-D-G7 , Rental Mobil.com\

1.Reynaldo Edwin Pratama 2.Wiwit Aulia Rahman  3.Fajar Aji Gilang  4.Januario KusGunaldo

Langkah Install Project :

git clone "https://github.com/mirza-alim-m/laravel2020-D-G3"
composer install
configuring file .env
php artisan migrate
php artisan db:seed --class=DatabaseSeeder
php artisan migrate:refresh
php artisan serve
