<?php $__env->startSection('about'); ?>
<br>
<br>

<div class="card mb-3"style="width: 1200px">
    <img src="<?php echo e(asset('assets/images/assasin.jpg')); ?>" style="height: 300px"class="card-img-top" alt="...">
    <div class="card-body">
      <h1 class="card-title">About Perusahaan</h1>
      <p class="card-text">Perusahaan ini di dirikan oleh empat orang yaitu : Reynaldo Edwin, Wiwit Aulia Rahman, Fajar Aji Gilang dan Kusgunaldo
          perusahan ini di dirikan pada tahun 20 juni 2020, perusahaan ini berbasis di bidang perentalan yaitu Rental Mobil
          dengan menghubungkan antara penyedia jasa rental dengan pelanggan dan untuk mempermudah antara penyedia jasa rental dan pelanggan untuk menyewa
          mobil 
      </p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\rentalmobil\resources\views/about.blade.php ENDPATH**/ ?>