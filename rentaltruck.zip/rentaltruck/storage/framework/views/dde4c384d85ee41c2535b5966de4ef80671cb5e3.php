

<div class="card-expand-md text-center">
    <div class=" bg-primary card-header">
      Featured
    </div>
    <div class="card-body">
      <h2 class="card-title">Tabassam Rental</h2>
      <h4 class="card-text">Tempatnya Rental Mobil Paling murah, aman dan terpercaya</h4>
      <a href="#" class="btn btn-primary">Selengkapnya bisa liat Profile</a>
    </div>
    <div class="bg-primary card-footer text-muted">
      @copyright  : Tabassam Rental
    </div>
  </div>

 <!--===============================================================================================-->
 <script src="<?php echo asset('assets/vendor/jquery/jquery-3.2.1.min.js'); ?>"></script>
 <!--===============================================================================================-->
     <script src="<?php echo asset('assets/vendor/vendor/animsition/js/animsition.min.js'); ?>"></script>
 <!--===============================================================================================-->
     <script src="<?php echo asset('assets/vendor/bootstrap/js/popper.js'); ?>"></script>
     <script src="<?php echo asset('assets/vendor/bootstrap/js/bootstrap.min.js'); ?>"></script>
 <!--===============================================================================================-->
     <script src="<?php echo asset('assets/vendor/select2/select2.min.js'); ?>"></script>
 <!--===============================================================================================-->
     <script src="<?php echo asset('assets/vendor/daterangepicker/moment.min.js'); ?>"></script>
     <script src="vendor/daterangepicker/daterangepicker.js"></script>
 <!--===============================================================================================-->
     <script src="<?php echo asset('assets/vendor/countdowntime/countdowntime.js'); ?>"></script>
 <!--===============================================================================================-->
     <script src="<?php echo asset('assets/js/main.js'); ?>"></script>
     <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
 </body>
 </html>
<?php /**PATH C:\xampp\htdocs\rentalmobil\resources\views/layouts/footer.blade.php ENDPATH**/ ?>