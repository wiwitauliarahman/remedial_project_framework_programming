<?php $__env->startSection('container'); ?>
<div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    TAMBAH KENDARAAN
                </div>
                <div class="card-body">
                    <a href="/kendaraan" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>

                    <form method="post" action="/kendaraan/create" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>



                        <div class="form-group">
                            <label>Platnomor</label>
                            <input name="kendaraan_platnomor" class="form-control" placeholder="Masukan Tarif Perhari"></input>

                             <?php if($errors->has('kendaraan_platnomor')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_platnomor')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Merk</label>
                            <input name="kendaraan_merk" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_merk')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_merk')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Tipe</label>
                            <input name="kendaraan_tipe" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_tipe')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_tipe')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Tahun</label>
                            <input name="kendaraan_tahunrakit" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_tahunrakit')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_tahunrakit')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Seat</label>
                            <input name="kendaraan_seat" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_seat')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_seat')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Foto</label>
                            <input type="file" name="kendaraan_foto" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_foto')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_foto')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>PDF</label>
                            <input type="file" name="kendaraan_pdf" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_pdf')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_pdf')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Fasilitas</label>
                            <input name="kendaraan_fasilitas" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_fasilitas')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_fasilitas')); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label>Status</label>
                            <input name="kendaraan_status" class="form-control" placeholder="Masukan Tarif Overtime"></input>

                             <?php if($errors->has('kendaraan_status')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kendaraan_status')); ?>

                                </div>
                            <?php endif; ?>

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>

                    </form>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\rentalmobil\resources\views/kendaraan_tambah.blade.php ENDPATH**/ ?>