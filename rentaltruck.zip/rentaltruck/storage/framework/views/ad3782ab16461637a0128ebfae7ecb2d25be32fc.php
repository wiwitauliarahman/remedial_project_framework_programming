<?php $__env->startSection('profile'); ?>
<br>
<br>

<div class="card mb-3"style="width: 1200px">
    <img src="<?php echo e(asset('assets/images/assasin.jpg')); ?>" style="height: 300px"class="card-img-top" alt="...">
    <div class="card-body">
      <h1 class="card-title">Profile Perusahaan</h1>
      <p class="card-text">Nama Perusahaan : Tabassam Rental.com
                           Di dirikan      : 20 juni 2020
                           email           :  tabassamrental@gmail.com
                           facebook        : Tabassam Rental
                           Twitter         : Tabassam Rental20
                           Instagram       : Tabassam Rental20
      </p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\rentalmobil\resources\views/profile.blade.php ENDPATH**/ ?>